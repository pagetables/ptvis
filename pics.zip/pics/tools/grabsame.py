from PIL import Image, ImageFile, PngImagePlugin

def getpixels(same, one, two):
  """
  Given two images of the same size, return a new PNG with only the same pixels
  in them. Differences will be removed.
  """
  diff = Image.new('RGB', one.size, color=0)
  pa = one.load()
  pb = two.load()
  for x in xrange(diff.size[0]):
    for y in xrange(diff.size[1]):
      if pa[x,y] != (0,0,0):
        if pa[x,y] == pb[x,y]:
          if same:
            diff.putpixel((x,y), pb[x,y])
        else:
          if not same:
            diff.putpixel((x,y), pb[x,y])
            
  return diff

def getsamepixels(a, b):
  return getpixels(True, a, b)

def getdiffpixels(a, b):
  return getpixels(False, a, b)
  
if __name__ == "__main__":
  import sys
  a = Image.open(sys.argv[1])
  b = Image.open(sys.argv[2])
  if 'diff' in sys.argv:
    ret = getdiffpixels(a,b)
  else:
    ret = getsamepixels(a,b)
  ret.save(sys.argv[3])